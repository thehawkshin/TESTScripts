if ! rpm -q --quiet "screen" ; then
    yum install -y "screen"
fi